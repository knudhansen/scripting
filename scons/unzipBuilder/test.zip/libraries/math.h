int add(int a, int b);
long add(long a, long b);
