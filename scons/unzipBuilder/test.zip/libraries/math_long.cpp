long add (long a, long b) {
  return a + b;
}
