#ifndef __QUIZZ_H__
#define __QUIZZ_H__

#include "question.h"

class Quizz {
private:
  char *name;
  int questionCount;
  Question **questions;

public:
  Quizz(const char *quizFilePath);
  
  const char* getName(void);
  int getQuestionCount(void);
  const char* getQuestion(int questionNumber);

};

#endif
