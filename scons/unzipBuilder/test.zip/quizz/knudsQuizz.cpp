#include <time.h>
#include <stdio.h>
#include <stdlib.h>

#include "quizz.h"

int main() {
  const char *quizFilePath="danskHistorie.quiz";

  Quizz *quizz = new Quizz(quizFilePath);
  printf("You selected quizz %s\n", quizz->getName());

  unsigned int seed = time(NULL);
  printf("seed = 0x%08x\n", seed);

  quizz->getQuestion(rand() % quizz->getQuestionCount());
//  DIR *dir = opendir(".");
//
//  if (dir != NULL) {
//    struct dirent *ent;
//    while (( ent = readdir(dir) ) != NULL) {
//      if (extension(ent->d_name) == ".quiz") {
//	printf("%s\n", basename(ent->d_name));
//      }
//    }
//    closedir(dir);
//  } else {
//    printf("Could not open current directory\n");
//  }

  return 0;
}
