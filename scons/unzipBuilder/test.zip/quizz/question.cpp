#include "question.h"

Question::Question(const char *question, const char *response, char **choices) {
  this->question = question;
  this->response = response;
  this->choices = choices;
}

const char* Question::getQuestion() {
  return this->question;
}

char* Question::getChoice(int choiceNumber) {
  return this->choices[choiceNumber];
}
