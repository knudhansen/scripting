#ifndef __QUESTION_H__
#define __QUESTION_H__

class Question {

 private:
  const char *question;
  const char *response;
  char **choices;

 public:
  //  Question(const char *quizFileLine);
  Question(const char *question, const char *response, char **choices);

  const char* getQuestion();
  char* getChoice(int choiceNumber);
};

#endif
