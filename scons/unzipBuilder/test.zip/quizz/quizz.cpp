#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "quizz.h"


Quizz::Quizz(const char *quizFilePath) {
  this->name = (char*)malloc((strlen(quizFilePath)+1)*sizeof(char));
  strcpy(this->name, quizFilePath);
  this->name[-1] = NULL; // make sure that the last character of the string is 0.

  this->questionCount = 5;
  this->questions = (Question**)malloc(this->questionCount * sizeof(Question*));
  for (int i = 0; i < this->questionCount; i++) {
    char* question = (char*)malloc(strlen("this is question x?") * sizeof(char));
    sprintf(question, "this is question %d?", i);
    printf("question> %s\n", question);
  }
}

const char* Quizz::getName(void) {
  return this->name;
}

int Quizz::getQuestionCount(void) {
  return 5;
}

const char* Quizz::getQuestion(int questionNumber) {
  return "knud";
}

